# GraphQL module release notes

## 3.2.2

- The Agent can load the module's skill, `module-graphql`. Its description was not valid
  YAML, so Copilot skipped the skill and answered "Skill not found".

## 3.2.1

- Settings → Modules shows the GraphQL module's name and description before it is
  installed.

## 3.2.0

- The GraphQL module is released apart from Services DevTools: install and update it in
  Settings → Modules. It works with Services DevTools 3.2.0 or newer.
- The module brings its Agent skill, `module-graphql`, with its request syntax and examples.
